import os
import json
import sqlite3
from telegram import Update
from telegram.ext import Updater, CommandHandler, CallbackContext

# ---------------- Telegram Bot Token from environment variable ----------------
TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")

# ---------------- Database Setup ----------------
conn = sqlite3.connect("store.db", check_same_thread=False)
cursor = conn.cursor()

# Users table (Telegram ID + Rank)
cursor.execute("""
CREATE TABLE IF NOT EXISTS Users (
    telegram_id INTEGER PRIMARY KEY,
    rank TEXT DEFAULT 'User'
)
""")

# Products table
cursor.execute("""
CREATE TABLE IF NOT EXISTS Products (
    product_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    price REAL,
    stock INTEGER
)
""")

# Orders table
cursor.execute("""
CREATE TABLE IF NOT EXISTS Orders (
    order_id INTEGER PRIMARY KEY AUTOINCREMENT,
    telegram_id INTEGER,
    products TEXT,
    total REAL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
)
""")
conn.commit()

# ---------------- Utility Functions ----------------
def check_user_permission(telegram_id: int, required_rank: str) -> bool:
    cursor.execute("SELECT rank FROM Users WHERE telegram_id=?", (telegram_id,))
    res = cursor.fetchone()
    return res and res[0] == required_rank

def add_order(telegram_id: int, products_list: list):
    total = sum([p["price"]*p["quantity"] for p in products_list])
    cursor.execute(
        "INSERT INTO Orders (telegram_id, products, total) VALUES (?, ?, ?)",
        (telegram_id, json.dumps(products_list), total)
    )
    conn.commit()
    return total

# ---------------- Bot Commands ----------------
def start(update: Update, context: CallbackContext):
    telegram_id = update.message.from_user.id
    cursor.execute("INSERT OR IGNORE INTO Users (telegram_id) VALUES (?)", (telegram_id,))
    conn.commit()
    update.message.reply_text(
        f"Welcome! Your Telegram ID: {telegram_id}\n"
        "Use /products to see available products."
    )

def list_products(update: Update, context: CallbackContext):
    cursor.execute("SELECT product_id, name, price, stock FROM Products")
    products = cursor.fetchall()
    if not products:
        update.message.reply_text("No products available.")
        return
    msg = "Available Products:\n"
    for p in products:
        msg += f"{p[0]}. {p[1]} - ${p[2]} - Stock: {p[3]}\n"
    update.message.reply_text(msg)

def place_order(update: Update, context: CallbackContext):
    telegram_id = update.message.from_user.id
    args = context.args
    if len(args) % 2 != 0:
        update.message.reply_text("Usage: /order product_id quantity ...")
        return
    products_list = []
    for i in range(0, len(args), 2):
        pid = int(args[i])
        qty = int(args[i+1])
        cursor.execute("SELECT name, price, stock FROM Products WHERE product_id=?", (pid,))
        p = cursor.fetchone()
        if not p:
            update.message.reply_text(f"Product ID {pid} not found")
            return
        name, price, stock = p
        if qty > stock:
            update.message.reply_text(f"Not enough stock for {name}")
            return
        products_list.append({"product_id": pid, "name": name, "price": price, "quantity": qty})
        cursor.execute("UPDATE Products SET stock=stock-? WHERE product_id=?", (qty, pid))
    total = add_order(telegram_id, products_list)
    update.message.reply_text(f"Order placed! Total: ${total}")

# ---------------- Main Function ----------------
def main():
    updater = Updater(TOKEN)
    dp = updater.dispatcher
    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(CommandHandler("products", list_products))
    dp.add_handler(CommandHandler("order", place_order))
    updater.start_polling()
    updater.idle()

if __name__ == "__main__":
    main()        elif event.update.callback_query:
            await event.update.callback_query.answer(
                "⚠️ حدث خطأ. يرجى المحاولة مرة أخرى.",
                show_alert=True
            )
    except:
        pass  # إذا فشل إرسال الرسالة، لا مشكلة


# ===== Graceful Shutdown =====
async def shutdown(signal_type=None):
    """
    إيقاف البوت بشكل آمن
    """
    if signal_type:
        logger.info(f"Received exit signal {signal_type.name}...")
    else:
        logger.info("Shutting down...")
    
    # إيقاف Health Server
    if health_server_task:
        health_server_task.cancel()
        try:
            await health_server_task
        except asyncio.CancelledError:
            pass
    
    # إغلاق اتصال البوت
    if bot:
        await bot.session.close()
    
    logger.info("Bot stopped successfully!")


# ===== Main Function =====
async def main():
    """
    الدالة الرئيسية لتشغيل البوت
    """
    global bot, dp, health_server_task
    
    logger.info("Starting Professional Telegram Store v2.2 Ultimate...")
    
    # تهيئة قاعدة البيانات
    try:
        await db_manager.init_db()
        logger.info("Database initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize database: {e}")
        return
    
    # إنشاء Bot و Dispatcher
    bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode="HTML"))
    dp = Dispatcher(storage=MemoryStorage())
    
    # تسجيل Error Handler
    dp.errors.register(error_handler)
    
    # تسجيل الميدلوير بالترتيب الصحيح
    # الترتيب مهم: ErrorHandler -> Throttling -> Admin -> Auth
    dp.message.middleware(ErrorHandlerMiddleware())
    
    throttling_middleware = ThrottlingMiddleware()
    dp.message.middleware(throttling_middleware)
    dp.message.middleware(AdminMiddleware())
    dp.message.middleware(AuthMiddleware())
    
    dp.callback_query.middleware(ErrorHandlerMiddleware())
    dp.callback_query.middleware(AdminMiddleware())
    dp.callback_query.middleware(AuthMiddleware())
    
    # تسجيل الموجهات (Routers) بالترتيب الصحيح
    # الأدمن أولاً لضمان عدم تداخل الأوامر
    dp.include_router(admin.router)
    dp.include_router(products.router)
    dp.include_router(admin_modes.router)
    dp.include_router(admin_orders.router)
    dp.include_router(admin_stats.router)
    dp.include_router(admin_broadcast.router)
    dp.include_router(admin_coupons.router)
    dp.include_router(admin_audit.router)
    dp.include_router(language.router)
    dp.include_router(payments.router)
    dp.include_router(user.router)
    
    # تشغيل Health Server في الخلفية
    health_server_task = asyncio.create_task(health_server())
    
    # تسجيل Signal Handlers للـ Graceful Shutdown
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(
            sig,
            lambda s=sig: asyncio.create_task(shutdown(s))
        )
    
    try:
        # حذف الـ Webhook القديم لضمان عمل الـ Polling
        await bot.delete_webhook(drop_pending_updates=True)
        logger.info("Webhook deleted, starting polling...")
        
        # بدء الـ Polling
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
        
    except Exception as e:
        logger.error(f"Error during polling: {e}", exc_info=True)
    finally:
        await shutdown()


# ===== Entry Point =====
if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user (KeyboardInterrupt)")
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
