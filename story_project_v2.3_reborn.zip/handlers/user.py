"""
معالج المستخدمين - v2.3 Production
التحسينات:
- دعم نظام السنتات (INTEGER) في جميع العمليات المالية
- منع Stale Data: جلب الأسعار وسعر الصرف من قاعدة البيانات في لحظة الشراء
- تحسين واجهة المستخدم وتأكيد الطلب
- دعم الكوبونات مع نظام السنتات
"""

from aiogram import Router, F, types, Bot
from aiogram.filters import CommandStart, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from database.manager import db_manager
from services.order_service import order_service
from utils.keyboards import get_main_menu, get_categories_keyboard, get_products_keyboard, get_order_confirm_keyboard
from utils.translations import get_text, get_user_language, TRANSLATIONS
from config.settings import OrderStatus, UserRole
from aiogram.types import InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
import logging

router = Router()
logger = logging.getLogger(__name__)

# ===== FSM States =====
class OrderProcess(StatesGroup):
    waiting_for_player_id = State()
    confirming = State()
    waiting_for_coupon = State()
    waiting_for_receipt = State()

# ===== المتجر والمنتجات =====
@router.message(F.text.in_(["🛒 المتجر", "🛒 Store"]))
async def show_categories(message: types.Message, user: dict):
    """عرض أقسام المتجر"""
    lang = get_user_language(user) or "ar"
    
    # التحقق من وجود طلب مفتوح (منع السبام)
    if await db_manager.has_open_order(user['telegram_id']):
        return await message.answer("⚠️ لديك طلب قيد المعالجة، يرجى انتظاره أولاً.")
    
    categories = await db_manager.get_categories()
    await message.answer("📁 اختر القسم:", reply_markup=get_categories_keyboard(categories))

@router.callback_query(F.data.startswith("cat_"))
async def show_products(callback: types.CallbackQuery):
    """عرض منتجات قسم معين"""
    cat_id = int(callback.data.split("_")[1])
    products = await db_manager.get_products(category_id=cat_id)
    # جلب سعر الصرف الحالي (بالسنتات)
    rate_cents = int(await db_manager.get_setting("dollar_rate", "1250000"))
    await callback.message.edit_text("📦 اختر المنتج:", reply_markup=get_products_keyboard(products, cat_id, rate_cents))

@router.callback_query(F.data.startswith("prod_"))
async def product_details(callback: types.CallbackQuery, state: FSMContext):
    """عرض تفاصيل منتج وطلب معرف اللاعب"""
    prod_id = int(callback.data.split("_")[1])
    product = await db_manager.get_product(prod_id)
    
    if not product:
        await callback.answer("❌ المنتج غير موجود", show_alert=True)
        return
    
    # جلب أحدث سعر صرف وسعر منتج (منع Stale Data)
    rate_cents = int(await db_manager.get_setting("dollar_rate", "1250000"))
    price_usd_cents = product['price_usd']
    price_local_cents = (price_usd_cents * rate_cents) // 100
    
    await state.update_data(selected_prod_id=prod_id)
    await state.set_state(OrderProcess.waiting_for_player_id)
    
    text = (
        f"📝 *{product['name']}*\n\n"
        f"📄 {product['description']}\n\n"
        f"💰 السعر: {price_usd_cents/100:.2f}$\n"
        f"💵 السعر المحلي: {price_local_cents/100:,.2f} ل.س\n\n"
        f"🆔 أدخل معرف اللاعب (Player ID):"
    )
    await callback.message.edit_text(text, parse_mode="Markdown")

@router.message(OrderProcess.waiting_for_player_id)
async def process_player_id(message: types.Message, state: FSMContext, user: dict):
    """معالجة معرف اللاعب وعرض تأكيد الطلب"""
    player_id = message.text.strip()
    if not player_id:
        await message.answer("⚠️ يرجى إدخال معرف اللاعب")
        return
    
    data = await state.get_data()
    product = await db_manager.get_product(data['selected_prod_id'])
    
    # جلب أحدث البيانات (منع Stale Data)
    rate_cents = int(await db_manager.get_setting("dollar_rate", "1250000"))
    price_usd_cents = product['price_usd']
    price_local_cents = (price_usd_cents * rate_cents) // 100
    
    await state.update_data(player_id=player_id)
    await state.set_state(OrderProcess.confirming)
    
    lang = get_user_language(user)
    text = (
        f"⚠️ *تأكيد الطلب*\n\n"
        f"📦 المنتج: {product['name']}\n"
        f"🆔 المعرف: `{player_id}`\n"
        f"💰 السعر: {price_local_cents/100:,.2f} ل.س ({price_usd_cents/100:.2f}$)\n\n"
        f"سيتم الخصم من رصيدك الداخلي عند التأكيد.\n"
        f"💰 رصيدك الحالي: {user['balance']/100:.2f}$"
    )
    await message.answer(text, reply_markup=get_order_confirm_keyboard(product['id'], lang), parse_mode="Markdown")

@router.callback_query(F.data.startswith("confirm_buy_"))
async def confirm_purchase(callback: types.CallbackQuery, state: FSMContext, user: dict, bot: Bot):
    """تأكيد الشراء باستخدام OrderService ونظام السنتات"""
    data = await state.get_data()
    product_id = data['selected_prod_id']
    player_id = data['player_id']
    coupon_code = data.get('coupon_code')
    
    # إنشاء الطلب (OrderService سيتكفل بجلب أحدث الأسعار والتحقق من الرصيد بالسنتات)
    success, message, order_id = await order_service.create_order(
        user_id=user['telegram_id'],
        product_id=product_id,
        player_id=player_id,
        payment_method_id=None,  # الدفع من الرصيد
        coupon_code=coupon_code
    )
    
    if success:
        await callback.message.edit_text(
            f"✅ تم إنشاء الطلب بنجاح!\n"
            f"📦 رقم الطلب: `#{order_id}`\n"
            f"💰 تم الخصم من رصيدك\n"
            f"⏳ جاري التنفيذ...",
            parse_mode="Markdown"
        )
        
        # إشعار الأدمن
        from config.settings import ADMIN_ID
        try:
            product = await db_manager.get_product(product_id)
            await bot.send_message(
                ADMIN_ID,
                f"🆕 *طلب جديد (مدفوع من الرصيد)*\n\n"
                f"🆔 رقم الطلب: `#{order_id}`\n"
                f"👤 المستخدم: @{user.get('username', 'N/A')} (`{user['telegram_id']}`)\n"
                f"📦 المنتج: {product['name']}\n"
                f"🆔 معرف اللاعب: `{player_id}`\n",
                parse_mode="Markdown"
            )
        except Exception as e:
            logger.error(f"Failed to notify admin: {e}")
    else:
        await callback.answer(f"❌ {message}", show_alert=True)
    
    await state.clear()
