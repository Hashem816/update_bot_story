"""
Database Manager - Ultimate Production Edition (v2.3 REBORN)
- Optimized for High Concurrency with Transactions
- Precision Financial Operations (Strict Integer Cents-based)
- Robust Error Handling and Atomic Operations
"""

import aiosqlite
import asyncio
import json
from typing import Optional, List, Dict, Any
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

try:
    from .models import *
except ImportError:
    from database.models import *

from config.settings import DB_PATH, OrderStatus

class DatabaseManager:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._db = None
        self._lock = asyncio.Lock()
        
    async def connect(self):
        if self._db is None:
            async with self._lock:
                if self._db is None:
                    self._db = await aiosqlite.connect(self.db_path, timeout=60)
                    self._db.row_factory = aiosqlite.Row
                    await self._db.execute("PRAGMA journal_mode=WAL")
                    await self._db.execute("PRAGMA foreign_keys=ON")
                    await self._db.execute("PRAGMA synchronous=NORMAL")
        return self._db

    async def init_db(self):
        db = await self.connect()
        async with self._lock:
            await db.execute(CREATE_USERS_TABLE)
            await db.execute(CREATE_USERS_INDEX)
            await db.execute(CREATE_CATEGORIES_TABLE)
            await db.execute(CREATE_PROVIDERS_TABLE)
            await db.execute(CREATE_PRODUCTS_TABLE)
            await db.execute(CREATE_ORDERS_TABLE)
            await db.execute(CREATE_FINANCIAL_LOGS_TABLE)
            await db.execute(CREATE_TRUST_LOGS_TABLE)
            await db.execute(CREATE_SETTINGS_TABLE)
            await db.execute(CREATE_PAYMENT_METHODS_TABLE)
            await db.execute(CREATE_COUPONS_TABLE)
            await db.execute(CREATE_COUPON_USAGE_TABLE)
            await db.execute(CREATE_AUDIT_LOGS_TABLE)
            await db.execute(CREATE_BROADCAST_HISTORY_TABLE)
            await db.execute(CREATE_RATE_LIMITS_TABLE)
            await db.execute(CREATE_ADMIN_SESSIONS_TABLE)
            
            for key, val in DEFAULT_SETTINGS:
                await db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (key, val))
            
            await db.commit()

    async def get_user(self, telegram_id: int) -> Optional[Dict[str, Any]]:
        db = await self.connect()
        async with db.execute("SELECT * FROM users WHERE telegram_id = ?", (telegram_id,)) as cursor:
            row = await cursor.fetchone()
            return dict(row) if row else None

    async def create_user(self, telegram_id: int, username: str, first_name: str = None, last_name: str = None, role: str = 'USER', language: str = 'ar'):
        db = await self.connect()
        async with self._lock:
            await db.execute(
                "INSERT OR IGNORE INTO users (telegram_id, username, first_name, last_name, role, language) VALUES (?, ?, ?, ?, ?, ?)",
                (telegram_id, username, first_name, last_name, role, language)
            )
            await db.commit()

    async def update_user_balance(self, user_id: int, amount: int, log_type: str, reason: str = None, admin_id: int = None, order_id: int = None) -> tuple[bool, Any]:
        """تحديث الرصيد بنظام السنتات الصارم (INTEGER)"""
        if not isinstance(amount, int):
            logger.error(f"Financial error: amount must be integer (cents). Got {type(amount)}")
            amount = int(round(float(amount)))

        db = await self.connect()
        async with self._lock:
            try:
                async with db.execute("SELECT balance FROM users WHERE telegram_id = ?", (user_id,)) as cursor:
                    user = await cursor.fetchone()
                    if not user: return False, "User not found"
                    
                    balance_before = user['balance']
                    balance_after = balance_before + amount
                    if balance_after < 0: return False, "Insufficient balance"
                    
                    await db.execute("UPDATE users SET balance = ? WHERE telegram_id = ?", (balance_after, user_id))
                    await db.execute("""
                        INSERT INTO financial_logs (user_id, order_id, type, amount, balance_before, balance_after, admin_id, reason)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """, (user_id, order_id, log_type, amount, balance_before, balance_after, admin_id, reason))
                    
                    await db.commit()
                    return True, balance_after
            except Exception as e:
                await db.rollback()
                logger.error(f"Balance update error: {e}")
                return False, str(e)

    async def get_product(self, product_id: int) -> Optional[Dict[str, Any]]:
        db = await self.connect()
        async with db.execute("SELECT * FROM products WHERE id = ?", (product_id,)) as cursor:
            row = await cursor.fetchone()
            return dict(row) if row else None

    async def get_products(self, category_id: int = None, only_active: bool = True) -> List[Dict[str, Any]]:
        db = await self.connect()
        query = "SELECT * FROM products WHERE 1=1"
        params = []
        if category_id:
            query += " AND category_id = ?"
            params.append(category_id)
        if only_active:
            query += " AND is_active = 1"
        async with db.execute(query, params) as cursor:
            return [dict(row) for row in await cursor.fetchall()]

    async def get_categories(self, only_active: bool = True) -> List[Dict[str, Any]]:
        db = await self.connect()
        query = "SELECT * FROM categories"
        if only_active: query += " WHERE is_active = 1"
        async with db.execute(query) as cursor:
            return [dict(row) for row in await cursor.fetchall()]

    async def create_order(self, user_id: int, product_id: int, player_id: str, price_usd: int, price_local: int, exchange_rate: int, status: str = OrderStatus.NEW) -> int:
        db = await self.connect()
        async with self._lock:
            cursor = await db.execute("""
                INSERT INTO orders (user_id, product_id, player_id, price_usd, price_local, exchange_rate, status)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (user_id, product_id, player_id, price_usd, price_local, exchange_rate, status))
            order_id = cursor.lastrowid
            await db.commit()
            return order_id

    async def has_open_order(self, user_id: int) -> bool:
        db = await self.connect()
        async with db.execute("SELECT 1 FROM orders WHERE user_id = ? AND status IN (?, ?, ?)", 
                             (user_id, OrderStatus.NEW, OrderStatus.PAID, OrderStatus.IN_PROGRESS)) as cursor:
            return await cursor.fetchone() is not None

    async def update_order_status(self, order_id: int, status: str, admin_notes: str = None, execution_type: str = 'MANUAL', operator_id: int = None):
        db = await self.connect()
        async with self._lock:
            await db.execute("UPDATE orders SET status = ?, admin_notes = ?, execution_type = ?, operator_id = ? WHERE id = ?", 
                             (status, admin_notes, execution_type, operator_id, order_id))
            await db.commit()

    async def get_order(self, order_id: int) -> Optional[Dict[str, Any]]:
        db = await self.connect()
        async with db.execute("""
            SELECT o.*, p.name as product_name, u.username, u.telegram_id
            FROM orders o
            JOIN products p ON o.product_id = p.id
            JOIN users u ON o.user_id = u.telegram_id
            WHERE o.id = ?
        """, (order_id,)) as cursor:
            row = await cursor.fetchone()
            return dict(row) if row else None

    async def get_setting(self, key: str, default: Any = None) -> Any:
        db = await self.connect()
        async with db.execute("SELECT value FROM settings WHERE key = ?", (key,)) as cursor:
            row = await cursor.fetchone()
            return row['value'] if row else default

    async def set_setting(self, key: str, value: str):
        db = await self.connect()
        async with self._lock:
            await db.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, value))
            await db.commit()

    async def get_payment_methods(self, only_active: bool = True) -> List[Dict[str, Any]]:
        db = await self.connect()
        query = "SELECT * FROM payment_methods WHERE deleted_at IS NULL"
        if only_active: query += " AND is_active = 1"
        async with db.execute(query) as cursor:
            return [dict(row) for row in await cursor.fetchall()]

    async def log_admin_action(self, admin_id: int, action: str, target_type: str = None, target_id: int = None, details: str = None):
        db = await self.connect()
        async with self._lock:
            await db.execute("INSERT INTO audit_logs (admin_id, action, target_type, target_id, details) VALUES (?, ?, ?, ?, ?)", 
                             (admin_id, action, target_type, target_id, details))
            await db.commit()

db_manager = DatabaseManager(DB_PATH)
