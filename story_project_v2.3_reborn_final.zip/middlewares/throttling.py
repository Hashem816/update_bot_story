"""
Middleware للتحكم بمعدل الطلبات (Rate Limiting) - v2.3
التحسينات:
- تطبيق الحماية على الرسائل والأزرار (CallbackQuery)
- منع محاولات الإغراق (Flood) والـ Race Conditions المالية
- استثناء الطاقم الإداري من القيود
"""

import time
import logging
from typing import Any, Awaitable, Callable, Dict
from aiogram import BaseMiddleware
from aiogram.types import Message, CallbackQuery
from config.settings import UserRole

logger = logging.getLogger(__name__)

class ThrottlingMiddleware(BaseMiddleware):
    """
    Middleware للتحكم بمعدل الطلبات
    يمنع المستخدمين من إرسال رسائل أو الضغط على الأزرار بشكل متكرر بسرعة
    """
    
    def __init__(self, slow_mode_delay: float = 0.8, flood_threshold: int = 12):
        """
        Args:
            slow_mode_delay: الحد الأدنى للوقت بين العمليات (بالثواني)
            flood_threshold: عدد العمليات المسموح بها في دقيقة واحدة
        """
        self.slow_mode_delay = slow_mode_delay
        self.flood_threshold = flood_threshold
        
        # تتبع آخر عملية لكل مستخدم
        self.user_last_action_time: Dict[int, float] = {}
        
        # تتبع عدد العمليات في الدقيقة الأخيرة
        self.user_action_count: Dict[int, list] = {}
        
        # تتبع المستخدمين المحظورين مؤقتاً
        self.temp_blocked: Dict[int, float] = {}

    async def __call__(
        self,
        handler: Callable[[Message | CallbackQuery, Dict[str, Any]], Awaitable[Any]],
        event: Message | CallbackQuery,
        data: Dict[str, Any]
    ) -> Any:
        user_id = event.from_user.id
        current_time = time.time()
        
        # استثناء الطاقم الإداري من Rate Limiting
        user_role = data.get('user_role', UserRole.USER)
        if user_role in [UserRole.SUPER_ADMIN, UserRole.OPERATOR, UserRole.SUPPORT]:
            return await handler(event, data)
        
        # التحقق من الحظر المؤقت
        if user_id in self.temp_blocked:
            block_until = self.temp_blocked[user_id]
            if current_time < block_until:
                remaining = int(block_until - current_time)
                if isinstance(event, Message):
                    await event.answer(f"⚠️ حماية من السبام: يرجى الانتظار {remaining} ثانية.")
                else:
                    await event.answer(f"⚠️ انتظر {remaining} ثانية.", show_alert=True)
                return
            else:
                del self.temp_blocked[user_id]
                self.user_action_count[user_id] = []
        
        # التحقق من Slow Mode (منع Race Conditions المالية)
        last_time = self.user_last_action_time.get(user_id, 0)
        if current_time - last_time < self.slow_mode_delay:
            if isinstance(event, CallbackQuery):
                await event.answer("⚠️ مهلاً! لا تضغط بسرعة كبيرة.", show_alert=False)
            return  # تجاهل العملية بصمت
        
        # التحقق من Flood Protection
        if user_id not in self.user_action_count:
            self.user_action_count[user_id] = []
        
        # تنظيف العمليات القديمة (أكثر من دقيقة)
        self.user_action_count[user_id] = [
            t for t in self.user_action_count[user_id]
            if current_time - t < 60
        ]
        
        # إضافة العملية الحالية
        self.user_action_count[user_id].append(current_time)
        
        # التحقق من تجاوز الحد
        if len(self.user_action_count[user_id]) > self.flood_threshold:
            # حظر مؤقت لمدة 60 ثانية
            self.temp_blocked[user_id] = current_time + 60
            logger.warning(f"Flood detected: User {user_id} sent {len(self.user_action_count[user_id])} actions/min")
            
            msg = "⚠️ تم اكتشاف نشاط مريب. تم حظرك مؤقتاً لمدة دقيقة واحدة لحماية النظام."
            if isinstance(event, Message):
                await event.answer(msg)
            else:
                await event.answer(msg, show_alert=True)
            return
        
        # تحديث آخر وقت عملية
        self.user_last_action_time[user_id] = current_time
        
        return await handler(event, data)
