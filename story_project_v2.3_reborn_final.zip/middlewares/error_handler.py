import logging
import traceback
from typing import Any, Awaitable, Callable, Dict
from aiogram import BaseMiddleware
from aiogram.types import Message, CallbackQuery
from config.settings import ADMIN_ID

logger = logging.getLogger(__name__)

class ErrorHandlerMiddleware(BaseMiddleware):
    """
    Middleware لمعالجة الأخطاء بشكل مركزي (v2.3)
    يمنع توقف البوت ويقوم بتسجيل الـ Stack Trace الكامل وإخطار الأدمن
    """
    async def __call__(
        self,
        handler: Callable[[Any, Dict[str, Any]], Awaitable[Any]],
        event: Any,
        data: Dict[str, Any]
    ) -> Any:
        try:
            return await handler(event, data)
        except Exception as e:
            user_id = event.from_user.id if hasattr(event, 'from_user') and event.from_user else "Unknown"
            full_traceback = traceback.format_exc()
            
            # تسجيل الخطأ في ملف الجول (Log File)
            logger.critical(f"CRITICAL ERROR for user {user_id}:\n{full_traceback}")
            
            # إخطار الأدمن فوراً بالـ Stack Trace الكامل كما ورد في Encyclopedia
            bot = data.get('bot')
            if bot and ADMIN_ID:
                try:
                    error_report = (
                        f"🚨 *خطأ حرج في النظام!*\n\n"
                        f"👤 المستخدم: `{user_id}`\n"
                        f"❌ الخطأ: `{str(e)}`\n\n"
                        f"🔍 *التفاصيل:*\n```python\n{full_traceback[:3000]}...\n```"
                    )
                    await bot.send_message(ADMIN_ID, error_report, parse_mode="Markdown")
                except Exception as notify_error:
                    logger.error(f"Failed to notify admin about error: {notify_error}")
            
            # إخطار المستخدم بطريقة ودية
            friendly_msg = "⚠️ عذراً، حدث خطأ فني غير متوقع. تم إبلاغ الإدارة تلقائياً وسنقوم بإصلاحه قريباً."
            try:
                if isinstance(event, Message):
                    await event.answer(friendly_msg)
                elif isinstance(event, CallbackQuery):
                    await event.answer(friendly_msg, show_alert=True)
            except Exception:
                pass
            
            return None
