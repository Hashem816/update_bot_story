"""
Middleware للمصادقة والصلاحيات - v2.3 REBORN
التحسينات:
- دعم البادئات الجديدة (adm_, ao_, ac_, ap_)
- إنفاذ صارم للصلاحيات (SUPPORT, OPERATOR, SUPER_ADMIN)
- حماية ضد الوصول غير المصرح به
"""

from typing import Any, Awaitable, Callable, Dict
from aiogram import BaseMiddleware
from aiogram.types import Message, CallbackQuery
from config.settings import ADMIN_IDS, StoreMode, UserRole
from database.manager import db_manager
import logging

logger = logging.getLogger(__name__)

class AdminMiddleware(BaseMiddleware):
    """
    Middleware للتحقق من صلاحيات الإدارة (v2.3 REBORN)
    يدعم البادئات المختصرة الجديدة ويفرض قيود الرتب.
    """
    
    async def __call__(
        self,
        handler: Callable[[Any, Dict[str, Any]], Awaitable[Any]],
        event: Message | CallbackQuery,
        data: Dict[str, Any]
    ) -> Any:
        user_id = event.from_user.id
        user = await db_manager.get_user(user_id)
        
        # تحديد الصلاحيات (توارث هرمي)
        is_super_admin = (user_id in ADMIN_IDS) or (user and user['role'] == UserRole.SUPER_ADMIN)
        is_operator = is_super_admin or (user and user['role'] == UserRole.OPERATOR)
        is_support = is_operator or (user and user['role'] == UserRole.SUPPORT)
        
        # تمرير الصلاحيات للمعالجات (Handlers)
        data['is_super_admin'] = is_super_admin
        data['is_admin'] = is_super_admin  # للتوافق
        data['is_operator'] = is_operator
        data['is_support'] = is_support
        data['user_role'] = user['role'] if user else UserRole.USER
        
        # حماية الـ Callback Queries الإدارية (البادئات الجديدة والقديمة)
        if isinstance(event, CallbackQuery):
            cbd = event.data
            admin_prefixes = ['adm_', 'ao_', 'ac_', 'ap_', 'admin_']
            
            if any(cbd.startswith(p) for p in admin_prefixes):
                # 1. التحقق الأدنى (SUPPORT)
                if not is_support:
                    logger.warning(f"Unauthorized access by {user_id}: {cbd}")
                    return await event.answer("⚠️ غير مصرح لك.", show_alert=True)
                
                # 2. قيود الـ SUPPORT (فقط الطلبات والعرض)
                # SUPPORT لا يمكنه الوصول للمنتجات (ac_, ap_) أو الإعدادات (adm_rate, adm_usrs, etc.)
                support_allowed = ['adm_ords', 'ao_v_']
                if not is_operator:
                    if not any(cbd.startswith(p) for p in support_allowed):
                        return await event.answer("⚠️ صلاحياتك محدودة بعرض الطلبات فقط.", show_alert=True)
                
                # 3. قيود الـ OPERATOR (المنتجات والطلبات، ولكن ليس الإعدادات المالية أو الكوبونات)
                operator_allowed = ['adm_ords', 'ao_', 'adm_prods', 'ac_', 'ap_', 'adm_paym']
                if not is_super_admin:
                    if not any(cbd.startswith(p) for p in operator_allowed):
                        return await event.answer("⚠️ هذا الإجراء متاح لمدير النظام فقط.", show_alert=True)
        
        return await handler(event, data)

class AuthMiddleware(BaseMiddleware):
    """
    Middleware للمصادقة العامة وحالة الحظر
    """
    async def __call__(
        self,
        handler: Callable[[Any, Dict[str, Any]], Awaitable[Any]],
        event: Message | CallbackQuery,
        data: Dict[str, Any]
    ) -> Any:
        user_id = event.from_user.id
        user = await db_manager.get_user(user_id)
        
        if not user:
            # إنشاء مستخدم جديد
            role = UserRole.SUPER_ADMIN if user_id in ADMIN_IDS else UserRole.USER
            await db_manager.create_user(
                user_id,
                event.from_user.username or "Unknown",
                first_name=event.from_user.first_name,
                last_name=event.from_user.last_name,
                role=role
            )
            user = await db_manager.get_user(user_id)
        
        # التحقق من الحظر
        if user['is_blocked']:
            msg = "🚫 حسابك محظور حالياً."
            if isinstance(event, Message): await event.answer(msg)
            else: await event.answer(msg, show_alert=True)
            return
            
        # التحقق من وضع الطوارئ (لغير الإداريين)
        is_staff = user['role'] in [UserRole.SUPER_ADMIN, UserRole.OPERATOR, UserRole.SUPPORT]
        if not is_staff:
            emergency = await db_manager.get_setting("emergency_stop", "0")
            if emergency == "1":
                msg = "🚨 المتجر متوقف مؤقتاً لحالة طوارئ."
                if isinstance(event, Message): await event.answer(msg)
                else: await event.answer(msg, show_alert=True)
                return

        data['user'] = user
        return await handler(event, data)
