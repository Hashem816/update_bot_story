"""
نظام إدارة طرق الدفع المحسّن - v2.3 Production
التحسينات:
- تطبيق Soft Delete الصارم (التأكد من deleted_at IS NULL في كل مكان)
- تحسين الأمان والتحقق من الصلاحيات
- تسجيل جميع العمليات في Audit Log
- عزل منطق قاعدة البيانات (Encapsulation)
"""

from aiogram import Router, F, types
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from database.manager import db_manager
from utils.keyboards import get_payment_methods_keyboard
import logging
from datetime import datetime

router = Router()
logger = logging.getLogger(__name__)

class PaymentMethodStates(StatesGroup):
    waiting_for_name = State()
    waiting_for_desc = State()

@router.callback_query(F.data == "adm_paym")
async def admin_payment_methods_main(callback: types.CallbackQuery, is_operator: bool):
    """القائمة الرئيسية لإدارة طرق الدفع مع التحقق من Soft Delete"""
    if not is_operator:
        await callback.answer("⛔️ غير مصرح لك", show_alert=True)
        return
    
    try:
        # get_payment_methods في manager.py تقوم بالفعل بفلترة المحذوفين
        methods = await db_manager.get_payment_methods(only_active=False)
        await callback.message.edit_text(
            "💳 *إدارة طرق الدفع*\n\nاختر طريقة لتعديلها أو أضف واحدة جديدة:", 
            reply_markup=get_payment_methods_keyboard(methods, is_admin=True), 
            parse_mode="Markdown"
        )
    except Exception as e:
        logger.error(f"Error in admin_payment_methods_main: {e}")
        await callback.answer("❌ حدث خطأ")

@router.callback_query(F.data == "admin_add_pay_start")
async def admin_add_pay_start(callback: types.CallbackQuery, state: FSMContext, is_operator: bool):
    if not is_operator: return
    await state.set_state(PaymentMethodStates.waiting_for_name)
    await callback.message.edit_text("💳 أدخل اسم طريقة الدفع الجديدة:")

@router.message(PaymentMethodStates.waiting_for_name)
async def admin_add_pay_name(message: types.Message, state: FSMContext):
    await state.update_data(name=message.text.strip())
    await state.set_state(PaymentMethodStates.waiting_for_desc)
    await message.answer("📝 أدخل تعليمات الدفع:")

@router.message(PaymentMethodStates.waiting_for_desc)
async def admin_add_pay_finish(message: types.Message, state: FSMContext, is_operator: bool):
    if not is_operator: return
    data = await state.get_data()
    desc = message.text.strip()
    
    try:
        db = await db_manager.connect()
        await db.execute(
            "INSERT INTO payment_methods (name, description, is_active) VALUES (?, ?, 1)", 
            (data['name'], desc)
        )
        await db.commit()
        
        await db_manager.log_admin_action(
            admin_id=message.from_user.id,
            action="CREATE_PAYMENT_METHOD",
            details=f"Name: {data['name']}"
        )
        
        await state.clear()
        await message.answer(f"✅ تم إضافة طريقة الدفع: {data['name']}")
    except Exception as e:
        logger.error(f"Error adding payment method: {e}")
        await message.answer("❌ فشل الإضافة")

@router.callback_query(F.data.startswith("admin_del_pay_confirm_"))
async def admin_delete_pay_execute(callback: types.CallbackQuery, is_operator: bool):
    """تنفيذ الحذف الآمن (Soft Delete)"""
    if not is_operator: return
    
    method_id = int(callback.data.split("_")[4])
    try:
        db = await db_manager.connect()
        # تحديث deleted_at بدلاً من حذف السجل (Soft Delete)
        await db.execute(
            "UPDATE payment_methods SET deleted_at = ?, is_active = 0 WHERE id = ?", 
            (datetime.now().isoformat(), method_id)
        )
        await db.commit()
        
        await db_manager.log_admin_action(
            admin_id=callback.from_user.id,
            action="SOFT_DELETE_PAYMENT_METHOD",
            target_id=method_id
        )
        
        await callback.answer("✅ تم الحذف بنجاح (Soft Delete)")
        await admin_payment_methods_main(callback, is_operator)
    except Exception as e:
        logger.error(f"Error in Soft Delete: {e}")
        await callback.answer("❌ فشل الحذف")
