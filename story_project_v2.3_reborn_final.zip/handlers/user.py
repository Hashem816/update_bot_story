"""
معالج المستخدمين - v2.3 REBORN Production
التحسينات:
- دعم البادئات المختصرة الجديدة (c_, p_, cb_, uc_)
- دعم نظام السنتات (INTEGER) في عرض الأسعار والخصم
- منع Stale Data: جلب الأسعار وسعر الصرف من قاعدة البيانات في لحظة الشراء
"""

from aiogram import Router, F, types, Bot
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from database.manager import db_manager
from services.order_service import order_service
from utils.keyboards import get_main_menu, get_categories_keyboard, get_products_keyboard, get_order_confirm_keyboard
from utils.translations import get_text, get_user_language
import logging

router = Router()
logger = logging.getLogger(__name__)

class OrderProcess(StatesGroup):
    waiting_for_player_id = State()
    confirming = State()
    waiting_for_coupon = State()

@router.message(CommandStart())
async def cmd_start(message: types.Message, user_role: str, user: dict):
    lang = get_user_language(user) or "ar"
    await message.answer(
        get_text("welcome", lang),
        reply_markup=get_main_menu(user_role, lang)
    )

@router.message(F.text.in_(["🛒 المتجر", "🛒 Store"]))
async def show_categories(message: types.Message, user: dict):
    if await db_manager.has_open_order(user['telegram_id']):
        return await message.answer("⚠️ لديك طلب قيد المعالجة، يرجى انتظاره أولاً.")
    
    categories = await db_manager.get_categories()
    await message.answer("📁 اختر القسم:", reply_markup=get_categories_keyboard(categories))

@router.callback_query(F.data == "back_to_cats")
async def back_to_categories(callback: types.CallbackQuery):
    categories = await db_manager.get_categories()
    await callback.message.edit_text("📁 اختر القسم:", reply_markup=get_categories_keyboard(categories))

@router.callback_query(F.data.startswith("c_"))
async def show_products(callback: types.CallbackQuery):
    cat_id = int(callback.data.split("_")[1])
    products = await db_manager.get_products(category_id=cat_id)
    rate_cents = int(await db_manager.get_setting("dollar_rate", "1250000"))
    await callback.message.edit_text("📦 اختر المنتج:", reply_markup=get_products_keyboard(products, cat_id, rate_cents))

@router.callback_query(F.data.startswith("p_"))
async def product_details(callback: types.CallbackQuery, state: FSMContext):
    prod_id = int(callback.data.split("_")[1])
    product = await db_manager.get_product(prod_id)
    
    if not product:
        return await callback.answer("❌ المنتج غير موجود", show_alert=True)
    
    rate_cents = int(await db_manager.get_setting("dollar_rate", "1250000"))
    price_usd_cents = product['price_usd']
    price_local_cents = (price_usd_cents * rate_cents) // 100
    
    await state.update_data(selected_prod_id=prod_id)
    await state.set_state(OrderProcess.waiting_for_player_id)
    
    text = (
        f"📝 *{product['name']}*\n\n"
        f"📄 {product['description']}\n\n"
        f"💰 السعر: {price_usd_cents/100:.2f}$\n"
        f"💵 السعر المحلي: {price_local_cents/100:,.0f} ل.س\n\n"
        f"🆔 أدخل معرف اللاعب (Player ID):"
    )
    await callback.message.edit_text(text, parse_mode="Markdown")

@router.message(OrderProcess.waiting_for_player_id)
async def process_player_id(message: types.Message, state: FSMContext, user: dict):
    player_id = message.text.strip()
    if not player_id:
        return await message.answer("⚠️ يرجى إدخال معرف اللاعب")
    
    data = await state.get_data()
    product = await db_manager.get_product(data['selected_prod_id'])
    rate_cents = int(await db_manager.get_setting("dollar_rate", "1250000"))
    price_usd_cents = product['price_usd']
    price_local_cents = (price_usd_cents * rate_cents) // 100
    
    await state.update_data(player_id=player_id)
    await state.set_state(OrderProcess.confirming)
    
    text = (
        f"⚠️ *تأكيد الطلب*\n\n"
        f"📦 المنتج: {product['name']}\n"
        f"🆔 المعرف: `{player_id}`\n"
        f"💰 السعر: {price_local_cents/100:,.0f} ل.س ({price_usd_cents/100:.2f}$)\n\n"
        f"سيتم الخصم من رصيدك الداخلي عند التأكيد.\n"
        f"💰 رصيدك الحالي: {user['balance']/100:.2f}$"
    )
    await message.answer(text, reply_markup=get_order_confirm_keyboard(product['id']), parse_mode="Markdown")

@router.callback_query(F.data.startswith("cb_"))
async def confirm_purchase(callback: types.CallbackQuery, state: FSMContext, user: dict, bot: Bot):
    data = await state.get_data()
    product_id = int(callback.data.split("_")[1])
    player_id = data['player_id']
    
    success, message, order_id = await order_service.create_order(
        user_id=user['telegram_id'],
        product_id=product_id,
        player_id=player_id,
        payment_method_id=None
    )
    
    if success:
        await callback.message.edit_text(
            f"✅ تم إنشاء الطلب بنجاح!\n"
            f"📦 رقم الطلب: `#{order_id}`\n"
            f"💰 تم الخصم من رصيدك\n"
            f"⏳ جاري التنفيذ...",
            parse_mode="Markdown"
        )
    else:
        await callback.answer(f"❌ {message}", show_alert=True)
    
    await state.clear()

@router.callback_query(F.data.startswith("uc_"))
async def use_coupon_start(callback: types.CallbackQuery, state: FSMContext):
    await state.set_state(OrderProcess.waiting_for_coupon)
    await callback.message.edit_text("🎟️ أدخل كود الكوبون:")
