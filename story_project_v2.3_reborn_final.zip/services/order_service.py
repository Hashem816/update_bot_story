"""
Order Service Layer - طبقة خدمات الطلبات (v2.3)
التحسينات:
- دعم نظام السنتات (INTEGER) للدقة المالية المليارية
- التحقق من المخزون والسعر وطريقة الدفع وحالة المتجر
- إنشاء طلب آمن مع Transactions
- دعم الوضع اليدوي والتلقائي ووضع الطوارئ
"""

import logging
import json
from typing import Optional, Dict, Any, Tuple
from datetime import datetime

from database.manager import db_manager
from config.settings import OrderStatus, ProductType, StoreMode

logger = logging.getLogger(__name__)

class OrderValidationError(Exception):
    """استثناء مخصص لأخطاء التحقق من الطلبات"""
    pass

class OrderService:
    """خدمة إدارة الطلبات"""
    
    @staticmethod
    async def validate_order(
        user_id: int,
        product_id: int,
        player_id: str,
        payment_method_id: Optional[int] = None
    ) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
        """
        التحقق من صلاحية الطلب قبل إنشائه (دعم نظام السنتات)
        """
        try:
            # 1. التحقق من المستخدم
            user = await db_manager.get_user(user_id)
            if not user:
                return False, "المستخدم غير موجود", None
            
            if user.get('is_blocked'):
                return False, "حسابك محظور. يرجى التواصل مع الدعم.", None
            
            # 2. التحقق من المنتج
            product = await db_manager.get_product(product_id)
            if not product:
                return False, "المنتج غير موجود", None
            
            if not product.get('is_active'):
                return False, "المنتج غير متاح حالياً", None
            
            if product.get('type') == ProductType.DISABLED:
                return False, "المنتج معطل", None
            
            # 3. التحقق من حالة المتجر
            store_mode = await db_manager.get_setting('store_mode', StoreMode.MANUAL)
            emergency_stop = await db_manager.get_setting('emergency_stop', '0')
            
            if emergency_stop == '1' or store_mode == 'EMERGENCY':
                return False, "⚠️ عذراً، المتجر في وضع الطوارئ حالياً لحماية العمليات. يرجى المحاولة لاحقاً.", None
            
            if store_mode == StoreMode.MAINTENANCE:
                return False, "🛠 عذراً، المتجر في وضع الصيانة حالياً للتحديث. سنعود للعمل قريباً!", None
            
            # 4. التحقق من وجود طلب مفتوح
            # ملاحظة: تم تفعيل هذا القيد لمنع السبام والعمليات المتكررة
            has_open = await db_manager.has_open_order(user_id)
            if has_open:
                return False, "لديك طلب قيد المعالجة. يرجى انتظار إتمامه أولاً.", None
            
            # 5. التحقق من طريقة الدفع (إذا كانت محددة)
            if payment_method_id:
                payment_method = await db_manager.get_payment_method(payment_method_id)
                if not payment_method:
                    return False, "طريقة الدفع غير موجودة", None
                
                if not payment_method.get('is_active'):
                    return False, "طريقة الدفع غير نشطة", None
            
            # 6. حساب السعر (بالسنتات)
            # سعر الصرف مخزن بالسنتات (مثلاً 1250000 تعني 12500.00)
            dollar_rate_cents = int(await db_manager.get_setting('dollar_rate', '1250000'))
            price_usd_cents = product['price_usd']
            # السعر المحلي = (سعر الدولار بالسنتات * سعر الصرف بالسنتات) / 10000 (للحفاظ على دقة السنتات)
            price_local_cents = (price_usd_cents * dollar_rate_cents) // 100
            
            # 7. التحقق من الرصيد (إذا كان الدفع من الرصيد)
            if payment_method_id is None:  # الدفع من الرصيد
                if user['balance'] < price_usd_cents:
                    needed = (price_usd_cents - user['balance']) / 100
                    current = user['balance'] / 100
                    return False, f"رصيدك غير كافٍ. تحتاج إلى {needed:.2f}$ إضافية. رصيدك الحالي {current:.2f}$", None
            
            # 8. التحقق من معرف اللاعب
            if not player_id or len(player_id.strip()) == 0:
                return False, "يرجى إدخال معرف اللاعب", None
            
            # إعداد بيانات الطلب
            order_data = {
                'user_id': user_id,
                'product_id': product_id,
                'product': product,
                'player_id': player_id.strip(),
                'price_usd': price_usd_cents,
                'price_local': price_local_cents,
                'exchange_rate': dollar_rate_cents,
                'payment_method_id': payment_method_id,
                'execution_type': product['type']  # MANUAL or AUTOMATIC
            }
            
            return True, "الطلب صالح", order_data
            
        except Exception as e:
            logger.error(f"Error validating order: {e}", exc_info=True)
            return False, f"خطأ في التحقق من الطلب: {str(e)}", None
    
    @staticmethod
    async def create_order(
        user_id: int,
        product_id: int,
        player_id: str,
        payment_method_id: Optional[int] = None,
        coupon_code: Optional[str] = None,
        metadata: Optional[Dict] = None
    ) -> Tuple[bool, str, Optional[int]]:
        """
        إنشاء طلب جديد مع جميع عمليات التحقق (نظام السنتات)
        """
        try:
            # 1. التحقق من صلاحية الطلب
            is_valid, message, order_data = await OrderService.validate_order(
                user_id, product_id, player_id, payment_method_id
            )
            
            if not is_valid:
                return False, message, None
            
            # 2. تطبيق الكوبون (إذا وجد)
            discount_amount_cents = 0
            final_price_usd_cents = order_data['price_usd']
            
            if coupon_code:
                is_valid_coupon, coupon_msg, discount_cents = await db_manager.validate_coupon(
                    coupon_code, user_id, final_price_usd_cents
                )
                
                if is_valid_coupon:
                    discount_amount_cents = discount_cents
                    final_price_usd_cents = max(0, final_price_usd_cents - discount_cents)
                    # ضمان الحد الأدنى للسعر (مثلاً 50 سنت) لتغطية التكاليف كما ورد في Encyclopedia
                    min_price_allowed = 50 
                    if final_price_usd_cents < min_price_allowed and order_data['price_usd'] >= min_price_allowed:
                        final_price_usd_cents = min_price_allowed
                        
                    logger.info(f"Coupon {coupon_code} applied: discount={discount_cents}, final_price={final_price_usd_cents}")
                else:
                    logger.warning(f"Invalid coupon {coupon_code}: {coupon_msg}")
            
            # 3. تحديد حالة الطلب الأولية
            if payment_method_id is None:
                initial_status = OrderStatus.PAID
            else:
                initial_status = OrderStatus.PENDING_PAYMENT
            
            # 4. إنشاء الطلب في قاعدة البيانات باستخدام Transaction
            db = await db_manager.connect()
            async with db.execute("BEGIN"):
                try:
                    # حساب السعر المحلي النهائي
                    final_price_local_cents = (final_price_usd_cents * order_data['exchange_rate']) // 100
                    
                    # إنشاء الطلب
                    metadata_json = json.dumps(metadata) if metadata else None
                    cursor = await db.execute("""
                        INSERT INTO orders (
                            user_id, product_id, player_id, 
                            price_usd, price_local, exchange_rate,
                            status, payment_method_id, execution_type, metadata
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        user_id,
                        product_id,
                        order_data['player_id'],
                        final_price_usd_cents,
                        final_price_local_cents,
                        order_data['exchange_rate'],
                        initial_status,
                        payment_method_id,
                        order_data['execution_type'],
                        metadata_json
                    ))
                    
                    order_id = cursor.lastrowid
                    
                    # إذا كان الدفع من الرصيد، خصم المبلغ
                    if payment_method_id is None:
                        success, result = await db_manager.update_user_balance(
                            user_id=user_id,
                            amount=-final_price_usd_cents,
                            log_type="PURCHASE",
                            reason=f"شراء منتج: {order_data['product']['name']}",
                            order_id=order_id
                        )
                        
                        if not success:
                            raise Exception(f"فشل خصم الرصيد: {result}")
                    
                    # تسجيل استخدام الكوبون
                    if coupon_code and discount_amount_cents > 0:
                        await db_manager.use_coupon(coupon_code, user_id, order_id, discount_amount_cents)
                    
                    # تسجيل في trust_logs
                    await db.execute("""
                        INSERT INTO trust_logs (order_id, user_id, action_text, execution_type)
                        VALUES (?, ?, ?, ?)
                    """, (
                        order_id,
                        user_id,
                        f"إنشاء طلب جديد #{order_id}",
                        order_data['execution_type']
                    ))
                    
                    await db.commit()
                    logger.info(f"Order created successfully: order_id={order_id}, user_id={user_id}")
                    return True, "تم إنشاء الطلب بنجاح", order_id
                    
                except Exception as e:
                    await db.rollback()
                    logger.error(f"Transaction failed in create_order: {e}")
                    return False, f"خطأ في إنشاء الطلب: {str(e)}", None
                
        except Exception as e:
            logger.error(f"Error in create_order: {e}", exc_info=True)
            return False, f"خطأ غير متوقع: {str(e)}", None
    
    @staticmethod
    async def finalize_order(
        order_id: int,
        status: str,
        admin_id: Optional[int] = None,
        admin_notes: Optional[str] = None
    ) -> Tuple[bool, str]:
        """
        إنهاء الطلب (إكمال أو فشل أو إلغاء) مع إرجاع الرصيد عند الفشل
        """
        try:
            order = await db_manager.get_order(order_id)
            if not order:
                return False, "الالطلب غير موجود"
            
            if status not in [OrderStatus.COMPLETED, OrderStatus.FAILED, OrderStatus.CANCELED]:
                return False, "حالة غير صالحة"
            
            # تحديث حالة الطلب
            await db_manager.update_order_status(
                order_id=order_id,
                status=status,
                admin_notes=admin_notes,
                execution_type=order.get('execution_type', 'MANUAL'),
                operator_id=admin_id
            )
            
            # إرجاع الرصيد عند الفشل أو الإلغاء إذا كان الدفع من الرصيد
            if status in [OrderStatus.FAILED, OrderStatus.CANCELED]:
                if order.get('payment_method_id') is None:
                    await db_manager.update_user_balance(
                        user_id=order['user_id'],
                        amount=order['price_usd'],
                        log_type="REFUND",
                        admin_id=admin_id,
                        reason=f"إرجاع رصيد الطلب #{order_id} - {status}",
                        order_id=order_id
                    )
            
            if admin_id:
                await db_manager.log_admin_action(
                    admin_id=admin_id,
                    action=f"FINALIZE_ORDER_{status}",
                    target_type="ORDER",
                    target_id=order_id,
                    details=f"إنهاء الطلب #{order_id} بحالة {status}"
                )
            
            return True, f"تم إنهاء الطلب بحالة: {status}"
            
        except Exception as e:
            logger.error(f"Error finalizing order: {e}")
            return False, f"خطأ في إنهاء الطلب: {str(e)}"

# إنشاء instance واحد من OrderService
order_service = OrderService()
