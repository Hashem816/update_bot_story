"""
Analytics Service - نظام الإحصائيات المحسّن (v2.3)
التحسينات:
- دعم نظام السنتات (INTEGER) في جميع الحسابات المالية
- إحصائيات شاملة للطلبات والإيرادات والمستخدمين
- نظام التسوية المالية (Financial Reconciliation) لمنع التسريب المالي
"""

from typing import Dict, Any, Optional
from datetime import datetime, timedelta
from database.manager import db_manager
from config.settings import OrderStatus
import logging

logger = logging.getLogger(__name__)

class AnalyticsService:
    """خدمة الإحصائيات والتحليلات"""
    
    @staticmethod
    async def get_dashboard_stats() -> Dict[str, Any]:
        """
        إحصائيات لوحة التحكم الرئيسية (دعم نظام السنتات)
        """
        try:
            db = await db_manager.connect()
            stats = {}
            
            # === إحصائيات المستخدمين ===
            async with db.execute("SELECT COUNT(*) as count FROM users") as cursor:
                stats['total_users'] = (await cursor.fetchone())['count']
            
            async with db.execute("SELECT COUNT(*) as count FROM users WHERE is_blocked = 1") as cursor:
                stats['blocked_users'] = (await cursor.fetchone())['count']
            
            async with db.execute("SELECT COUNT(*) as count FROM users WHERE date(created_at) = date('now')") as cursor:
                stats['new_users_today'] = (await cursor.fetchone())['count']
            
            # === إحصائيات الطلبات ===
            async with db.execute("SELECT COUNT(*) as count FROM orders") as cursor:
                stats['total_orders'] = (await cursor.fetchone())['count']
            
            async with db.execute("SELECT COUNT(*) as count FROM orders WHERE status = ?", (OrderStatus.COMPLETED,)) as cursor:
                stats['completed_orders'] = (await cursor.fetchone())['count']
            
            async with db.execute("SELECT COUNT(*) as count FROM orders WHERE status = ?", (OrderStatus.IN_PROGRESS,)) as cursor:
                stats['pending_orders'] = (await cursor.fetchone())['count']
            
            # === الإحصائيات المالية (التحويل من سنتات إلى دولارات للعرض) ===
            async with db.execute("SELECT COALESCE(SUM(balance), 0) as total FROM users") as cursor:
                stats['total_balance_cents'] = (await cursor.fetchone())['total']
                stats['total_balance'] = stats['total_balance_cents'] / 100
            
            async with db.execute("""
                SELECT COALESCE(SUM(price_usd), 0) as revenue 
                FROM orders 
                WHERE status = ?
            """, (OrderStatus.COMPLETED,)) as cursor:
                stats['total_revenue_cents'] = (await cursor.fetchone())['revenue']
                stats['total_revenue'] = stats['total_revenue_cents'] / 100
            
            async with db.execute("""
                SELECT COALESCE(SUM(price_usd), 0) as revenue 
                FROM orders 
                WHERE status = ? AND date(created_at) = date('now')
            """, (OrderStatus.COMPLETED,)) as cursor:
                stats['revenue_today_cents'] = (await cursor.fetchone())['revenue']
                stats['revenue_today'] = stats['revenue_today_cents'] / 100

            # === نظام التسوية المالية (Financial Reconciliation) ===
            # التحقق من أن مجموع العمليات المالية يطابق الرصيد الحالي للمستخدمين
            async with db.execute("""
                SELECT 
                    (SELECT COALESCE(SUM(amount), 0) FROM financial_logs) as total_logs,
                    (SELECT COALESCE(SUM(balance), 0) FROM users) as current_total_balance
            """) as cursor:
                recon = await cursor.fetchone()
                stats['reconciliation_diff'] = (recon['total_logs'] - recon['current_total_balance']) / 100
                stats['is_financial_healthy'] = abs(stats['reconciliation_diff']) < 0.01

            # === معدلات النجاح ===
            if stats['total_orders'] > 0:
                stats['success_rate'] = (stats['completed_orders'] / stats['total_orders']) * 100
            else:
                stats['success_rate'] = 0
            
            return stats
            
        except Exception as e:
            logger.error(f"Error getting dashboard stats: {e}", exc_info=True)
            return {}
    
    @staticmethod
    async def get_orders_by_status() -> Dict[str, int]:
        """إحصائيات الطلبات حسب الحالة"""
        try:
            db = await db_manager.connect()
            async with db.execute("""
                SELECT status, COUNT(*) as count 
                FROM orders 
                GROUP BY status
            """) as cursor:
                results = await cursor.fetchall()
                return {row['status']: row['count'] for row in results}
        except Exception as e:
            logger.error(f"Error getting orders by status: {e}")
            return {}

    @staticmethod
    async def get_financial_audit_report() -> Dict[str, Any]:
        """
        تقرير تدقيق مالي شامل لكشف أي "تسريب" أو أخطاء برمجية في الحسابات
        """
        try:
            db = await db_manager.connect()
            report = {}
            
            # 1. إجمالي الشحن (Deposits)
            async with db.execute("SELECT COALESCE(SUM(amount), 0) FROM financial_logs WHERE type = 'DEPOSIT'") as cursor:
                report['total_deposits'] = (await cursor.fetchone())[0] / 100
                
            # 2. إجمالي المشتريات (Purchases)
            async with db.execute("SELECT COALESCE(SUM(amount), 0) FROM financial_logs WHERE type = 'PURCHASE'") as cursor:
                # المشتريات تكون سالبة في اللوج، لذا نأخذ القيمة المطلقة
                report['total_purchases'] = abs((await cursor.fetchone())[0]) / 100
                
            # 3. إجمالي المبالغ المستردة (Refunds)
            async with db.execute("SELECT COALESCE(SUM(amount), 0) FROM financial_logs WHERE type = 'REFUND'") as cursor:
                report['total_refunds'] = (await cursor.fetchone())[0] / 100
                
            # 4. الرصيد الحالي الفعلي في جدول المستخدمين
            async with db.execute("SELECT COALESCE(SUM(balance), 0) FROM users") as cursor:
                report['actual_users_balance'] = (await cursor.fetchone())[0] / 100
                
            # 5. الرصيد المتوقع (شحن - مشتريات + مستردات + تعديلات أدمن)
            async with db.execute("SELECT COALESCE(SUM(amount), 0) FROM financial_logs") as cursor:
                report['expected_balance_from_logs'] = (await cursor.fetchone())[0] / 100
                
            # 6. حساب الفجوة (Leakage)
            report['leakage'] = report['expected_balance_from_logs'] - report['actual_users_balance']
            report['status'] = "HEALTHY" if abs(report['leakage']) < 0.01 else "WARNING"
            
            return report
        except Exception as e:
            logger.error(f"Error in financial audit: {e}")
            return {'status': 'ERROR', 'message': str(e)}

# إنشاء instance واحد
analytics_service = AnalyticsService()
